#!/bin/zsh
set -e
DIR="${0:A:h}"
open "$DIR/curso/index.html"
